import { Loandetails } from './loandetails';

describe('Loandetails', () => {
  it('should create an instance', () => {
    expect(new Loandetails()).toBeTruthy();
  });
});
