export class Register {
    firstName!: string;
      lastName!: string;
      emailid!:string;
      password!: string;
      phoneNumber!: string;
      dob!: string;
      nationality!: string;
      aadharno!: string;
      pancardno! :string;
      Status!:string;
}
