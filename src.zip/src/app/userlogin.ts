export class Userlogin {
    emailid!:string;
      password!: string;
}
