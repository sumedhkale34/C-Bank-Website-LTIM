export class Personal {
    FirstName!: string;
      LastName!: string;
      EmailId!:string;
      Password!: string;
      PhoneNumber!: string;
      Dob!: Date;
      Gender!:string;
      Nationality!: string;
      AadharNo!: string;
      PanCardNo! :string;

      MaxLoan !: string;
      LoanAmount !: string;
      LoanTenure !: number;
      Emi!: string;
      LoanDate!: Date;

      ReqId !:number;
      RequestDate !: Date;
      Status !: string;
}
