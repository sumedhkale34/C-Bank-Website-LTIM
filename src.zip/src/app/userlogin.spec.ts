import { Userlogin } from './userlogin';

describe('Userlogin', () => {
  it('should create an instance', () => {
    expect(new Userlogin()).toBeTruthy();
  });
});
