export class Loanrequest {
    BankAccountNo !: string;
    ReqId !: number;
    EmailId!: string;
    PropertyName !: string;
    Propertystreet !: string;
    Propertycity !: string;
    Propertystate !: string;
    EmploymentType !: string;
    OrganizationType !: string;
    RetirementAge !: number;
    MonthlyIncome !: string;
    EstimatedAmount !: string;
    RequestEmi !: string;
    Tenure !: number;
    RequestDate !: Date;
    Status !: string;
}
