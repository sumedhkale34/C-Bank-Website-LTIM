export class Tracker {
    reqid!:string;
    accno!:string;
    Status!:string;
}
