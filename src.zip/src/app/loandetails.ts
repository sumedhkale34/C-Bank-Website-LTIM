export class Loandetails {
    bankaccountno !: string;
      emailid !: string;
      maxloan !: string;
      loanamount !: string;
      loantenure !: number;
      emi!: string;
      loandate!: Date;
}
