import { Personal } from './personal';

describe('Personal', () => {
  it('should create an instance', () => {
    expect(new Personal()).toBeTruthy();
  });
});
