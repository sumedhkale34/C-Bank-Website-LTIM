import { Tracker } from './tracker';

describe('Tracker', () => {
  it('should create an instance', () => {
    expect(new Tracker()).toBeTruthy();
  });
});
