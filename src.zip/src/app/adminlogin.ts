export class Adminlogin {
    emailid!:string;
      password!: string;
}
