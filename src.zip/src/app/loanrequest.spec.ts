import { Loanrequest } from './loanrequest';

describe('Loanrequest', () => {
  it('should create an instance', () => {
    expect(new Loanrequest()).toBeTruthy();
  });
});
